<?php
    const BASE_URL = "/ignite/";
    const USER_CITY = array("Select","Toronto","Montreal","Calgary","Ottawa","Edmonton","Mississauga","Vancouver","Hamilton","Brampton","Surrey");
    const USER_PROFESSIONS = array("Select","Student","Engineer","Artist","Pilot","Trading","Politician","Unemployed");
?>