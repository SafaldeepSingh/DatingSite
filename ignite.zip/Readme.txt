Github url- https://github.com/SafaldeepSingh/DatingSite

INSTALLATION 
1)(changes to be done in shared/constants.php)-
	change the "BASE_URL" to path of your project folder on server
	Eg:- project is in "htdocs/ignite", Then BASE_URL = "/ignite/"
2) Import Database from ignite.sql
3) Change the port as per your configurations in "Model/Database.php" & "shared/Database.php"

We have set Dummy chat bw John & Mara,their email & passwords are-
John-	email-John@gmail.com	password-John123
Mara-	email-Mara@gmail.com	password-Mara123

By Default Premium users are as follows-
Mara		username-Mara@gmail.com		password-Mara123
Rohith		username-rohith@gmail.com	password-rohith123		
Safaldeep	username-safal@gmail.com	password-123456
Emmma		username-Emma@gmail.com		password-Emma123
Zendaya		username-zendaya@gmail.com	password-zendaya123	
Anuj 		username-anuj@gmail.com		password-anuj123
Venky 		username-venky@gmail.com	password-123456
Jenny		username-jenny@gmail.com	password-jenny789
Tom 		username-tom@gmail.com		password-tom123
 